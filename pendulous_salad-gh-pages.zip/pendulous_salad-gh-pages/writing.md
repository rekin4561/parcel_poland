---
layout: category_index
title: Writing
permalink: /writing/
category_name: writing
---

<!--

Set the front matter:
title = your page title and link name in the navigation
permalink = the url for the page, i.e. example.com/my-awesome-category
category_name = the name of the cateogry you want to use to group posts, you'll need to use the same name on post pages

Save this page in the root directory.
Use the same name for the filename as the permalink, i.e.

permalink: /my-awesome-category/
filename: my-awesome-category.html

-->
